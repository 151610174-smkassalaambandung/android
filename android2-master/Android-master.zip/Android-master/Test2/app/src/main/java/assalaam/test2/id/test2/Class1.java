package assalaam.test2.id.test2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Class1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_class1);
    }
}
