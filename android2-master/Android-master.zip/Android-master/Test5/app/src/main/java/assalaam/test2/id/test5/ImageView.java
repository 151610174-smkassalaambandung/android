package assalaam.test2.id.test5;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class ImageView extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image_view);
    }
}
