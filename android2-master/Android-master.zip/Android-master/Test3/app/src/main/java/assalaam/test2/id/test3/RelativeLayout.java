package assalaam.test2.id.test3;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class RelativeLayout extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_relative_layout);
    }
}
